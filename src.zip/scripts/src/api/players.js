import * as GameTest from '@minecraft/server-gametest';
import { world, system, Vector } from '@minecraft/server';
import { Core } from 'src/sapling.js'


const { ephemeral, print, server } = Core.World;

// Client Object
const Client = {

    Connect: function(...args) {
        // Config declarations
        const DB = args[0], username = args[1], sender = args[2], event = args[3], gamemode = args[4];
        const exist = DB.findIndex(x => x.Player.name === username);
        // Fakeplayer connection check
        if (exist >= 0) return ephemeral(`§7${username} are connected`,sender)
        // Fakeplayer connection
        const FAKEPLAYER = event.spawnSimulatedPlayer(new Vector(0,4,0), username)
        FAKEPLAYER.setGameMode(gamemode == 'creative' || gamemode == 'creative' ? gamemode : 'survival');
        FAKEPLAYER.teleport(sender.location, sender.dimension, sender.location.x, sender.location.y);
        FAKEPLAYER.runCommandAsync('spawnpoint @s')
        // Pushed player to DB
        DB.push({ Player: FAKEPLAYER, Actions: [] })
    },

    Disconnect: function(...args) {
        // Config declarations
        const DB = args[0], username = args[1], sender = args[2], event = args[3];
        const exist = DB.findIndex(x => x.Player.name === username);
        // Fakeplayer disconnection check
        if (exist < 0) return ephemeral('§8You can only manipulate existing players',sender);
        // Fakeplayer disconnection
        const FAKEPLAYER = DB[exist].Player;
        FAKEPLAYER.kill();
        event.removeSimulatedPlayer(FAKEPLAYER)
        // Removed player from DB
        DB.splice(exist, 1);
    },

    Actions: function(...args) {
        // Config declarations
        const EVENT = args[0], DB = args[1], username = args[2], sender = args[3], action = args[4];
        const exist = DB.findIndex(x => x.Player.name === username);
        // Fakeplayer disconnection check
        if (exist < 0) return ephemeral('§8You can only manipulate existing players',sender);
        // Fakeplayer action
        const FAKEPLAYER = DB[exist].Player;
        if (action == 'jump') FAKEPLAYER.jump();
        else if (action == 'attack') FAKEPLAYER.attack();
        else if (action == 'tp') FAKEPLAYER.teleport(sender.location, sender.dimension, sender.location.x, sender.location.y);
        else if (action == 'shift') FAKEPLAYER.isSneaking ? FAKEPLAYER.isSneaking = false : FAKEPLAYER.isSneaking = true;
        else if (action == 'respawn') FAKEPLAYER.respawn();
        else if (action == 'use') FAKEPLAYER.useItemInSlot(args[5] >= 0 || args[5] <= 9 ? parseInt(args[5]) : FAKEPLAYER.selectedSlot);
        else if (action == 'interact') FAKEPLAYER.interact();
        else if (action == 'rotate') FAKEPLAYER.rotateBody(parseInt(args[5]) || 20);
        // Repeat action
        else if (action == 'repeat') {
            const ACTIONS = DB[exist].Actions;
            if (
                args[5] == 'jump' ||
                args[5] == 'attack' ||
                args[5] == 'use' || 
                args[5] == 'interact'
            ) ACTIONS.push(args[5]);
            else ephemeral('§7Invalid action to repeat',sender);
        }
        // Stop action
        else if (action == 'stop') DB[exist].Actions = [];
    }
    
}

// Fakeplayer server
GameTest.registerAsync('Sapling','Fakeplayer', async FAKEPLAYER => {

    // Players DB
    let PLAYERS = [];
    print('§7Fakeplayer server started...');

    // Repeat Actions
    system.runInterval(() => {
        if (PLAYERS.length == 0) return;
        PLAYERS.forEach(x => x.Actions.forEach(z => {
            Client.Actions(FAKEPLAYER,PLAYERS,x.Player.name,world.getDimension('overworld'),z)
        }))
    },2)

    // Input Methods
    world.events.beforeChat.subscribe(ev => {
        // Config declarations
        let msg = ev.message.split(' ');
        const sdr = ev.sender;  
        // Check first message argument
        if (msg[0] != './player') return;
        ev.cancel = true;
        msg.splice(0,1)
        // Server Reload
        if (msg[0] == 'server') {
            if (msg[1] == '?') ephemeral('§2Server methods:\n§r§3 - reload §8=> Reload a fakeplayer server§r\n§3 - guide §8=> Show all fakeplayer guide§r\n§3 - users §8=> Show all fakeplayers connected§r\n§3 - cls/clear §8=> Clear chat§r',sdr);
            else if (msg[1] == 'reload') { FAKEPLAYER.succeed(); server('fakeplayer') }
            else if (msg[1] == 'cls' || msg[1] == 'clear') ephemeral('\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n',sdr)
            else if (msg[1] == 'guide') ephemeral('§2Fakeplayer Methods:\n§r§3 - ./player <username> spawn <optional:survival/creative> §8=> Spawns a fakeplayer§r\n§3 - ./player <username> kill §8=> Removes a fakeplayer§r\n§3 - ./player <username> respawn §8=> Fakeplayer respawn§r\n§3 - ./player <username> tp §8=> Fakeplayer tp§r\n§3 - ./player <username> rotate <0-360> §8=> Rotate a fakeplayer§r\n§3 - ./player <username> jump §8=> Fakeplayer jump action§r\n§3 - ./player <username> attack §8=> Fakeplayer attack action§r\n§3 - ./player <username> use <0-9> §8=> Fakeplayer use action§r\n§3 - ./player <username> interact §8=> Fakeplayer interact action§r\n§3 - ./player <username> shift §8=> Fakeplayer shift action§r\n§3 - ./player <username> repeat <use/interact/jump/attack> §8=> Fakeplayer repeat actions§r\n§3 - ./player <username> stop §8=> Fakeplayer stop repeat actions§r',sdr);
            else if (msg[1] == 'users') { 
                if (PLAYERS.length == 0) return ephemeral('r§7Not players found§r',sdr)
                ephemeral('§2Fakeplayers connected:§r',sdr);
                PLAYERS.forEach(x => ephemeral(`§3 - ${x.Player.name}§r`,sdr) );
            }
            else ephemeral("server it's a reserved word, check methods with './player server ?'",sdr)
        }
        // Connect, Disconnect && Actions 
        else if (msg[1] == 'spawn') Client.Connect(PLAYERS,msg[0],sdr,FAKEPLAYER,msg[2]);
        else if (msg[1] == 'kill') Client.Disconnect(PLAYERS,msg[0],sdr,FAKEPLAYER);
        else if (
            msg[1] == 'jump' || msg[1] == 'attack' || msg[1] == 'shift' ||
            msg[1] == 'tp' || msg[1] == 'repeat' ||  msg[1] == 'stop' ||
            msg[1] == 'interact' || msg[1] == 'respawn' || msg[1] == 'use' ||
            msg[1] == 'rotate'
        ) Client.Actions(FAKEPLAYER,PLAYERS,msg[0],sdr,msg[1],msg[2]);
        // Invalid Action
        else ephemeral('Syntax error',sdr);
    })

})
    .maxTicks(999999999)
    .structureName('FP:Server');

// Init Fakeplayer server
server('fakeplayer');