import { world, Vector } from '@minecraft/server'
import { Core } from 'src/sapling.js'

const { getData } = Core.NBT;

world.events.beforeItemUseOn.subscribe(cactus => {
    const { item } = cactus;
    if (item.typeId != 'minecraft:cactus' || !getData('flippinCactus')) return;
    input(cactus)
})

function input (cactus) {
    // Set Config Values
    const block = cactus.source.getBlockFromViewDirection(), data = block.typeId.replace('minecraft:','');
    const LIST = [
        'piston','sticky_piston','observer',
        'dropper','dispenser','hopper',
        'unpowered_repeater','powered_repeater',
        'unpowered_comparator','powered_comparator'
    ]
    const LIST2 = ['piston','sticky_piston','observer']
    const LIST3 = ['dropper','dispenser']
    if (!LIST.includes(data)) return
    // Replace Function
    if (LIST2.includes(data)) return replace(block,data);
    else if (LIST3.includes(data)) return containers(block,data);
    if (['unpowered_repeater','powered_repeater'].includes(data)) {
        const GETS = {
            dir: block.permutation.getProperty('direction'),
            bit: block.permutation.getProperty('repeater_delay')
        }
        const { x, y, z } = block;
        if (GETS.dir == 0) return block.dimension.runCommandAsync(`structure load repeater:bit${GETS.bit} ${x} ${y} ${z} 90_degrees`);
        else if (GETS.dir == 1) return block.dimension.runCommandAsync(`structure load repeater:bit${GETS.bit} ${x} ${y} ${z} 180_degrees`);
        else if (GETS.dir == 2) return block.dimension.runCommandAsync(`structure load repeater:bit${GETS.bit} ${x} ${y} ${z} 270_degrees`);
        else if (GETS.dir == 3) return block.dimension.runCommandAsync(`structure load repeater:bit${GETS.bit} ${x} ${y} ${z} 0_degrees`);
    } else if (['unpowered_comparator','powered_comparator'].includes(data)) {
        const GETS = {
            dir: block.permutation.getProperty('direction'),
            bit: block.permutation.getProperty('output_subtract_bit')
        }
        const { x, y, z } = block;
        if (GETS.dir == 0) return block.dimension.runCommandAsync(`structure load comparator:${GETS.bit} ${x} ${y} ${z} 90_degrees`);
        else if (GETS.dir == 1) return block.dimension.runCommandAsync(`structure load comparator:${GETS.bit} ${x} ${y} ${z} 180_degrees`);
        else if (GETS.dir == 2) return block.dimension.runCommandAsync(`structure load comparator:${GETS.bit} ${x} ${y} ${z} 270_degrees`);
        else if (GETS.dir == 3) return block.dimension.runCommandAsync(`structure load comparator:${GETS.bit} ${x} ${y} ${z} 0_degrees`);
    }
}

function replace(block,data) {
    const { x, y, z } = block;
    const direction = block.permutation.getProperty('facing_direction');
    if (direction == 2) return block.dimension.runCommandAsync(`structure load ${data}:up ${x} ${y} ${z}`);
    else if (direction == 0) return block.dimension.runCommandAsync(`structure load ${data}:north ${x} ${y} ${z}`);
    else if (direction == 1) return block.dimension.runCommandAsync(`structure load ${data}:weast ${x} ${y} ${z}`);
    else if (direction == 4) return block.dimension.runCommandAsync(`structure load ${data}:south ${x} ${y} ${z}`);
    else if (direction == 3) return block.dimension.runCommandAsync(`structure load ${data}:east ${x} ${y} ${z}`);
    else if (direction == 5) return block.dimension.runCommandAsync(`structure load ${data}:down ${x} ${y} ${z}`);
}

function containers(block,data) {
    const { x, y, z } = block;
    let container = block.getComponent('inventory').container;
    const direction = block.permutation.getProperty('facing_direction');
    
    let items = [];
    for (let x = 0; x < container.size; x++) {
        const slot = container.getItem(x);
        items.push(slot);
        Core.World.print(slot)
    }
    
    if (direction == 2)  block.dimension.runCommandAsync(`structure load ${data}:up ${x} ${y} ${z}`);
    else if (direction == 0) block.dimension.runCommandAsync(`structure load ${data}:north ${x} ${y} ${z}`);
    else if (direction == 1) block.dimension.runCommandAsync(`structure load ${data}:weast ${x} ${y} ${z}`);
    else if (direction == 4) block.dimension.runCommandAsync(`structure load ${data}:south ${x} ${y} ${z}`);
    else if (direction == 3) block.dimension.runCommandAsync(`structure load ${data}:east ${x} ${y} ${z}`);
    else if (direction == 5) block.dimension.runCommandAsync(`structure load ${data}:down ${x} ${y} ${z}`);
    
    const newBlock = block.dimension.getBlock(new Vector(x,y,z));
    container = newBlock.getComponent('inventory').container;
    for (let x = 0; x < container.size; x++) {
        if (items[x] == undefined) return; 
        container.setItem(x,items[x]);
        Core.World.print(items[x]);
    }
}